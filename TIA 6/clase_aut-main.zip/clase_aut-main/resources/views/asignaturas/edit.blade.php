@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Editar Asignatura</h2>
        <a class="btn btn-primary" href="{{ route('asignaturas.index') }}"> Volver</a>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>¡Ups!</strong> Hubo algunos problemas con tu entrada.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('asignaturas.update', $asignatura->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="row">
            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label for="nombre"><strong>Nombre:</strong></label>
                    <input type="text" name="nombre" value="{{ old('nombre', $asignatura->nombre) }}" class="form-control" placeholder="Nombre de la Asignatura">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label for="programa_id"><strong>Programa:</strong></label>
                    <select name="programa_id" id="programa_id" class="form-control">
                        <option value="">Selecciona un Programa</option>
                        @foreach ($programas as $programa)
                            <option value="{{ $programa->id }}" {{ old('programa_id', $asignatura->programa_id) == $programa->id ? 'selected' : '' }}>
                                {{ $programa->nombre }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-md-12 text-center">
                <button type="submit" class="btn btn-success">Actualizar</button>
            </div>
        </div>
    </form>
</div>
@endsection