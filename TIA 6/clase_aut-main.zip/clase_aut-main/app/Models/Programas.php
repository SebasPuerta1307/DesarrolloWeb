<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Programas extends Model
{
   use HasFactory;

    protected $fillable = ['id', 'nombre','departamento_id'];
}
