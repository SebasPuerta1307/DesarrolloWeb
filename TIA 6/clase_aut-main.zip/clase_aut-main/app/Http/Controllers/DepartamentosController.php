


<?php

namespace App\Http\Controllers;

use App\Models\Departamento;
use App\Models\Facultad; // Necesitamos este modelo para el select de facultades
use Illuminate\Http\Request;

class DepartamentoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $departamentos = Departamento::with('facultad')->latest()->paginate(10); // Carga la relación facultad
        return view('departamentos.index', compact('departamentos'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $facultades = Facultad::orderBy('nombre')->get(); // Obtener todas las facultades para el select
        return view('departamentos.create', compact('facultades'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'facultad_id' => 'required|exists:facultades,id',
        ]);

        Departamento::create($request->all());

        return redirect()->route('departamentos.index')
                         ->with('success', 'Departamento creado exitosamente.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Departamento $departamento)
    {
        // Carga la relación facultad para mostrarla
        $departamento->load('facultad');
        return view('departamentos.show', compact('departamento'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Departamento $departamento)
    {
        $facultades = Facultad::orderBy('nombre')->get();
        // Carga la relación facultad para el formulario de edición
        $departamento->load('facultad');
        return view('departamentos.edit', compact('departamento', 'facultades'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Departamento $departamento)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'facultad_id' => 'required|exists:facultades,id',
        ]);

        $departamento->update($request->all());

        return redirect()->route('departamentos.index')
                         ->with('success', 'Departamento actualizado exitosamente.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Departamento $departamento)
    {
        $departamento->delete();

        return redirect()->route('departamentos.index')
                         ->with('success', 'Departamento eliminado exitosamente.');
    }
}