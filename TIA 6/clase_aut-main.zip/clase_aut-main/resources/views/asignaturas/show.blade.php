@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Detalle de la Asignatura</h2>
        <a class="btn btn-primary" href="{{ route('asignaturas.index') }}"> Volver</a>
    </div>

    <div class="card">
        <div class="card-header">
            <strong>Información de la Asignatura</strong>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-12 mb-2">
                    <div class="form-group">
                        <strong>Nombre:</strong>
                        {{ $asignatura->nombre }}
                    </div>
                </div>
                <div class="col-md-12 mb-2">
                    <div class="form-group">
                        <strong>Programa:</strong>
                        {{ $asignatura->programa->nombre ?? 'N/A' }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection