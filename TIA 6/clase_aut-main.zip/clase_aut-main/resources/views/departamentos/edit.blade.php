@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Editar Departamento</h2>
        <a class="btn btn-primary" href="{{ route('departamentos.index') }}"> Volver</a>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>¡Ups!</strong> Hubo algunos problemas con tu entrada.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('departamentos.update', $departamento->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="row">
            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label for="nombre"><strong>Nombre:</strong></label>
                    <input type="text" name="nombre" value="{{ old('nombre', $departamento->nombre) }}" class="form-control" placeholder="Nombre del Departamento">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label for="facultad_id"><strong>Facultad:</strong></label>
                    <select name="facultad_id" id="facultad_id" class="form-control">
                        <option value="">Selecciona una Facultad</option>
                        @foreach ($facultades as $facultad)
                            <option value="{{ $facultad->id }}" {{ old('facultad_id', $departamento->facultad_id) == $facultad->id ? 'selected' : '' }}>
                                {{ $facultad->nombre }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-md-12 text-center">
                <button type="submit" class="btn btn-success">Actualizar</button>
            </div>
        </div>
    </form>
</div>
@endsection
