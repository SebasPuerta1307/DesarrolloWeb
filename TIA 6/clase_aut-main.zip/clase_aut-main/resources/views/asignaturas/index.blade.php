@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Listado de Asignaturas</h2>
        <a href="{{ route('asignaturas.create') }}" class="btn btn-primary">Crear Nueva Asignatura</a>
    </div>

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Programa</th>
                <th width="280px">Acciones</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($asignaturas as $asignatura)
            <tr>
                <td>{{ $asignatura->id }}</td>
                <td>{{ $asignatura->nombre }}</td>
                <td>{{ $asignatura->programa->nombre ?? 'N/A' }}</td>
                <td>
                    <form action="{{ route('asignaturas.destroy', $asignatura->id) }}" method="POST">
                        <a class="btn btn-info btn-sm" href="{{ route('asignaturas.show', $asignatura->id) }}">Mostrar</a>
                        <a class="btn btn-primary btn-sm" href="{{ route('asignaturas.edit', $asignatura->id) }}">Editar</a>
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar esta asignatura?')">Eliminar</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="4">No hay asignaturas registradas.</td>
            </tr>
            @endforelse
        </tbody>
    </table>

    {!! $asignaturas->links() !!}
</div>
@endsection