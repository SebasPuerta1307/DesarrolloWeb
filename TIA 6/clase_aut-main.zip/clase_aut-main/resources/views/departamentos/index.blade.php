@extends('layouts.app') {{-- Asume que tienes una plantilla base en layouts/app.blade.php --}}

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Listado de Departamentos</h2>
        <a href="{{ route('departamentos.create') }}" class="btn btn-primary">Crear Nuevo Departamento</a>
    </div>

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Facultad</th>
                <th width="280px">Acciones</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($departamentos as $departamento)
            <tr>
                <td>{{ $departamento->id }}</td>
                <td>{{ $departamento->nombre }}</td>
                <td>{{ $departamento->facultad->nombre ?? 'N/A' }}</td>
                <td>
                    <form action="{{ route('departamentos.destroy', $departamento->id) }}" method="POST">
                        <a class="btn btn-info btn-sm" href="{{ route('departamentos.show', $departamento->id) }}">Mostrar</a>
                        <a class="btn btn-primary btn-sm" href="{{ route('departamentos.edit', $departamento->id) }}">Editar</a>
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar este departamento?')">Eliminar</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="4">No hay departamentos registrados.</td>
            </tr>
            @endforelse
        </tbody>
    </table>

    {!! $departamentos->links() !!} {{-- Para la paginación --}}
</div>
@endsection
